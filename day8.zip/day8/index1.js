function exampleswitch()
{
    ch=prompt("Please enter  choice (1 ADD 2 SUB 3 MUL)");
    ch = parseInt(ch);
    if(ch>=1 && ch<=3)
    {
        var a = prompt("Enter  a =");
        var b = prompt("Enter b ");
        a = parseInt(a);
        b = parseInt(b);
    } 
    switch(ch)
    {        
        case 1:res = a+b;
              alert("Sum = "+ res);              
              break;
        default:alert("NOT a valid choice");
                break;
        case 2:res = a-b;
            alert("Difference = "+ res);
            break;
        case 3:res = a*b;
            alert("PRODUCT = "+ res);
            break;
    }   
}